<?php

namespace app\admin\controller;

/**
 * 系统首页
 * @author hardphp@163.com
 */
class Index extends System
{

    public function index()
    {

    }
}
