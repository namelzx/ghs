<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-01
 * Time: 15:09
 */

namespace app\admin\model;


use think\Model;

class PositionModel extends Model
{
    protected $table='tp_position';


}