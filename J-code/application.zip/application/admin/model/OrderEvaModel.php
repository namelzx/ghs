<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-28
 * Time: 13:02
 */

namespace app\admin\model;


use think\Model;

class OrderEvaModel extends Model
{
    protected $table = 'tp_order_eva';


}