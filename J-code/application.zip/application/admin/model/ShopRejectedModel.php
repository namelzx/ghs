<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-01-29
 * Time: 02:31
 */

namespace app\admin\model;


use think\Model;

class ShopRejectedModel extends Model
{
    protected $table='tp_shop_rejected';


}