<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-01-27
 * Time: 22:11
 */

namespace app\admin\model;


use think\Model;

class WechatUserModel extends Model
{
    protected $table='tp_wechat_user';

}