<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-28
 * Time: 23:13
 */

namespace app\admin\model;


use think\Model;

class UserModel extends Model
{

    protected $table='ee_user';
}