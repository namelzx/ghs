<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-18
 * Time: 17:30
 */

namespace app\admin\model;


use think\Model;

class ShopProjectModel extends Model
{
    protected $table = 'tp_shop_project';

}