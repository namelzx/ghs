<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-07
 * Time: 22:27
 */

namespace app\admin\model;


use think\Model;

class OrderNoteModel extends Model
{

    protected $table = 'tp_order_note';
    protected $createTime = 'create_time';

}