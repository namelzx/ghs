<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-08
 * Time: 22:49
 */

namespace app\admin\model;


use think\Model;

class OrderSaleModel extends Model
{
    protected $table = 'tp_order_sale';
    protected $createTime = 'create_time';

}