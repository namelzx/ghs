<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-24
 * Time: 01:34
 */

namespace app\admin\model;


use think\Model;

class OrderReturnedModel extends Model
{
    protected $table='tp_order_returned';
    protected $createTime='create_time';

}