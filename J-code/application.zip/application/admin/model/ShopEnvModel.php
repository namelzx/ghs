<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-01-27
 * Time: 22:42
 */

namespace app\admin\model;


use think\Model;

/**
 * Class ShopEnvModel
 * @package app\admin\model
 * 店内环境表
 */
class ShopEnvModel extends Model
{
    protected $table='tp_shop_env';

}