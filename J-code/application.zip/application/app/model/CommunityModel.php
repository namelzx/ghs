<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-08
 * Time: 23:26
 */

namespace app\app\model;


use think\Model;

class CommunityModel extends Model
{
    protected $table = 'ee_community';

}