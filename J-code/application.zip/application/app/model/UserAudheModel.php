<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-10
 * Time: 23:39
 */

namespace app\app\model;


use think\Model;

class UserAudheModel extends Model
{
    protected $table = 'ee_user_audhe';
    protected $createTime = '';

}