<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-07
 * Time: 03:12
 */

namespace app\app\model;


use think\Model;

class GoodsModel extends Model
{
    protected $table='ee_goods';

}