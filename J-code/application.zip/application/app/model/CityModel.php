<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-05
 * Time: 04:15
 */

namespace app\app\model;


use think\Model;

class CityModel extends Model
{
    protected $table = 'ee_city';

}