<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-11-24
 * Time: 17:21
 */

namespace app\index\controller;


use think\App;
use think\Controller;
use think\Db;

class Base extends Controller
{

    public function __construct(App $app = null)
    {
        parent::__construct($app);




    }

}