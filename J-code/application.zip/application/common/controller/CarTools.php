<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-03
 * Time: 17:31
 */

namespace app\common\controller;


use app\admin\model\CarBrandModel;

class CarTools extends Base
{


}