<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-07-19
 * Time: 23:25
 */

namespace app\common\model;


use think\Model;

class DemandModel extends Model
{
    protected $table = 'gg_demand';
    protected $createTime = 'create_time';


}