<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-31
 * Time: 05:44
 */

namespace app\common\model;


use think\Model;

class CommissionModel extends Model
{
    protected $table = 'ee_commission';
    protected $createTime = 'create_time';

}