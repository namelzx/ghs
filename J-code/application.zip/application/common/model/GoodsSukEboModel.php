<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-08-06
 * Time: 13:19
 */

namespace app\common\model;


use think\Model;

//买断
class GoodsSukEboModel extends Model
{
    protected $table = 'gg_goods_suk_ebo';
}