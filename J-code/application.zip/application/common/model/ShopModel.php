<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-02-28
 * Time: 02:11
 */

namespace app\common\model;


use think\Model;

class ShopModel extends Model
{
    protected $table='tp_shop';

}