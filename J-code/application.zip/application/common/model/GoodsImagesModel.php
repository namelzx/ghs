<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-07-13
 * Time: 16:40
 */

namespace app\common\model;


use think\Model;

//商品图片表
class GoodsImagesModel extends Model
{
    protected $table = 'gg_goods_images';

}