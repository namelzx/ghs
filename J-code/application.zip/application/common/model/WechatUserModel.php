<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-12-03
 * Time: 23:15
 */

namespace app\common\model;


class WechatUserModel extends BaseModel
{
    protected $table = 'tp_wechat_user';
    protected $createTime = 'create_time';

}