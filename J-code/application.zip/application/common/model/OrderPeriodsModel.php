<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-07-19
 * Time: 15:07
 */

namespace app\common\model;


use think\Model;

class OrderPeriodsModel extends Model
{
    protected $table = 'gg_order_periods';

}