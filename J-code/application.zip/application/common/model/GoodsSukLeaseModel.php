<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-08-06
 * Time: 13:20
 */

namespace app\common\model;


use think\Model;

//suk租期
class GoodsSukLeaseModel extends Model
{
    protected $table = 'gg_goods_suk_lease';

}