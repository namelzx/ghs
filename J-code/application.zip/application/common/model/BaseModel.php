<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2019-12-03
 * Time: 23:16
 */

namespace app\common\model;


use think\Model;

class BaseModel extends Model{

}