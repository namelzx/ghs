<?php
/**
 * Created by PhpStorm.
 * User: lzx
 * Date: 2020-03-31
 * Time: 23:38
 */

namespace app\common\model;


use think\Model;

class ConfigModel extends Model
{

    protected $table = 'ee_config';
}