/**
 * Created by laixinyu on 2018/6/1
 **/

Component({
    data: {},

    ready() {
    },

    methods: {}
});