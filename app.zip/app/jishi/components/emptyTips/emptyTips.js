// components/emptyTips/emptyTips.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    emptyIcon:{
      type:String,
      value:''
    },
    emptyTips:{
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },
  ready(){
    // console.log(this.properties.emptyTips)
  },
  /**
   * 组件的方法列表
   */
  methods: {

  }
})
