module.exports = {
  data: {
  },
  state: {
  },
  others: {
    pageUrl: "communitySearchPage"
  }
}