module.exports = {
  data: {
    show:false,
    value:0,
    countDown: '00:00',
    orderDetail: {
      // complete_address: "内蒙古自治区呼和浩特市新城区北京北京市东城区111",
      // confirm_time: 0,
      // contact: "111",
      // create_time: 1540202626,
      // freight: 0,
      // has_after_sale: 0,
      // items: [{
      //   amount: 1390,
      //   application_id: null,
      //   goods_logo: "https://static.newkr.net/goods/20180914/135241-DnCaQ5GCRHBc0NrI.jpg",
      //   goods_name: "即食蚕蛹五香多口味高营养高蛋白补品两袋250克",
      //   has_after_sale: 0,
      //   id: 273,
      //   number: 1,
      //   real_price: 1390,
      //   sku_name: "2袋",
      //   tracking_number: "",
      // }],
      // mobile: "18813750848",
      // order_id: "20181022180346813013",
      // order_status: 0,
      // order_status_desc: "待付款",
      // pay_type: "微信支付",
      // trade_no: "201810221803468422672889",
    },
    objectProdetail: null
  },
  state: {
    shareGroupStatus: false
  },
  others: {
    pageUrl: "orderDetailPage"
  }
}