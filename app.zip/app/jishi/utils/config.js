const config = {
  api_blink_url: 'https://ch.10huisp.com/api/app/',
  api_images_url: 'https://ch.10huisp.com/',
}

export { config }