你好，请使用下面的链接创建 issue 以帮助我们更快的排查问题，不规范的 issue 会被关闭，感谢配合。

https://youzan.github.io/vant-issue-generater?repo=VantWeapp
